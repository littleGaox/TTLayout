//
//  ViewController.m
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import "ViewController.h"
#import "TXTStackLayoutComponent.h"
#import <Masonry/Masonry.h>
#import <UIKit/UIKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self layout];
}

- (void)layout {
    // 测试点击事件用的，看容器是否会劫持底部事件
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(didClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    // 水平布局元素 start
    UIView *horizontalv = [self create:UIColor.blackColor];
    [[horizontalv.heightAnchor constraintEqualToConstant:100] setActive:YES];
    [[horizontalv.widthAnchor constraintEqualToConstant:100] setActive:YES];
    TXTStackLayoutItem *horizontalitem = [TXTStackLayoutItem itemWithView:horizontalv
                                                         config:(TXTStackLayoutItemConfig){
        .spacingBefore = 10,
        .spacingAfter = 10,
    }];
    
    UIView *horizontalv1 = [self create:UIColor.yellowColor];
    [[horizontalv1.heightAnchor constraintEqualToConstant:50] setActive:YES];
    [[horizontalv1.widthAnchor constraintEqualToConstant:80] setActive:YES];
    TXTStackLayoutItem *horizontalitem1 = [TXTStackLayoutItem itemWithView:horizontalv1
                                                          config:(TXTStackLayoutItemConfig){
        .spacingBefore = 10,
        .spacingAfter = 50,
        .align = TXTStackLayoutItemAlignmentLeft,
    }];
    
    
    UIView *horizontalv2 = [self create:UIColor.blueColor];
    [[horizontalv2.heightAnchor constraintEqualToConstant:150] setActive:YES];
    [[horizontalv2.widthAnchor constraintEqualToConstant:40] setActive:YES];
    TXTStackLayoutItem *horizontalitem2 = [TXTStackLayoutItem itemWithView:horizontalv2 config:(TXTStackLayoutItemConfig){
        .spacingBefore = 20,
        .spacingAfter = 10,
    }];
    
    NSArray *horizontalArray = @[horizontalitem, horizontalitem1, horizontalitem2];

    TXTStackLayoutComponent *horizontalcomponent = [TXTStackLayoutComponent stackLayoutWithAttribute:(TXTStackLayoutAttribute){
        .style = TXTStackLayoutStyleHorizontal,
        .alignmentItem = TXTStackLayoutItemAlignmentCenter,
    } items:horizontalArray];
    // 水平布局元素 end
    
    // 垂直布局元素 start
    TXTStackLayoutItem *verticalitem = [TXTStackLayoutItem itemWithComponent:horizontalcomponent config:(TXTStackLayoutItemConfig){
        .spacingBefore = 20,
        .spacingAfter = 10,
    }];
    
    UIView *verticalv1 = [self create:UIColor.blueColor];
    [[verticalv1.heightAnchor constraintEqualToConstant:80] setActive:YES];
    [[verticalv1.widthAnchor constraintEqualToConstant:80] setActive:YES];
    TXTStackLayoutItem *verticalitem1 = [TXTStackLayoutItem itemWithView:verticalv1 config:(TXTStackLayoutItemConfig){
        .spacingBefore = 100,
        .spacingAfter = 10,
    }];
    
    TXTStackLayoutItem *verticalitem2 = [TXTStackLayoutItem itemWithView:[[UIView alloc] init] config:(TXTStackLayoutItemConfig){
        .spacingBefore = 100,
        .spacingAfter = 10,
    }];
    
    TXTStackLayoutComponent *verticalComponent = [TXTStackLayoutComponent stackLayoutWithAttribute:(TXTStackLayoutAttribute){
        .style = TXTStackLayoutStyleVertical,
        .alignmentItem = TXTStackLayoutItemAlignmentLeft,
        .alignmentSelf = TXTStackLayoutAlignmentLeftTop,
    } items:@[verticalitem, verticalitem1, verticalitem2]];
    
    // 垂直布局元素 end
    [verticalComponent setupToView:self.view];
}

- (UIView *)create:(UIColor *)color {
    UIButton  * v = [[UIButton alloc] initWithFrame:CGRectZero];
    [v addTarget:self action:@selector(layoutSubv) forControlEvents:UIControlEventTouchUpInside];
    v.backgroundColor = color;
    return v;
}

- (void)layoutSubv {
    NSLog(@"=====");
}

- (void)didClick:(UIButton *)btn {
    CGRect re = btn.frame;
    re.origin.y += 10;
    btn.frame = re;
    NSLog(@"234234234234234234234234234");
}

@end
