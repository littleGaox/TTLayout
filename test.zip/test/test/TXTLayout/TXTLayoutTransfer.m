//
//  TXTLayoutTransfer.m
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import "TXTLayoutTransfer.h"

@implementation TXTLayoutHorizontalLeftTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.bottom.mas_equalTo(0);
    make.top.mas_greaterThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.left.mas_equalTo(current.config.spacingBefore);
        return;
    }
    CGFloat offset = current.config.spacingBefore + item.config.spacingAfter;
    make.left.mas_equalTo(item.view.mas_right).mas_offset(offset);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.right.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.right.mas_equalTo(item.view.mas_left).mas_offset(-offset);
}

@end

@implementation TXTLayoutHorizontalRightTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.top.mas_equalTo(0);
    make.bottom.mas_lessThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.left.mas_equalTo(current.config.spacingBefore);
        return;
    }
    make.left.mas_equalTo(item.view.mas_right).mas_offset(current.config.spacingBefore + item.config.spacingAfter);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.right.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.right.mas_equalTo(item.view.mas_left).mas_offset(-offset);
}

@end

@implementation TXTLayoutHorizontalCenterTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.centerY.mas_equalTo(0);
    make.bottom.mas_lessThanOrEqualTo(0);
    make.top.mas_greaterThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.left.mas_equalTo(current.config.spacingBefore);
        return;
    }
    make.left.mas_equalTo(item.view.mas_right).mas_offset(current.config.spacingBefore + item.config.spacingAfter);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.right.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.right.mas_equalTo(item.view.mas_left).mas_offset(-offset);
}

@end

@implementation TXTLayoutHorizontalStrentchTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.centerY.mas_equalTo(0);
    make.bottom.mas_lessThanOrEqualTo(0);
    make.right.mas_greaterThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    
}

@end

@implementation TXTLayoutVerticalLeftTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.left.mas_equalTo(0);
    make.right.mas_lessThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.top.mas_equalTo(current.config.spacingBefore);
        return;
    }
    make.top.mas_equalTo(item.view.mas_bottom).offset(current.config.spacingBefore + item.config.spacingAfter);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.bottom.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.bottom.mas_equalTo(item.view.mas_top).mas_offset(-offset);
}

@end

@implementation TXTLayoutVerticalRightTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.left.mas_equalTo(0);
    make.right.mas_lessThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.top.mas_equalTo(current.config.spacingBefore);
        return;
    }
    make.top.mas_equalTo(item.view.mas_bottom).offset(current.config.spacingBefore + item.config.spacingAfter);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.bottom.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.bottom.mas_equalTo(item.view.mas_top).mas_offset(-offset);
}

@end

@implementation TXTLayoutVerticalCenterTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    make.left.mas_equalTo(0);
    make.right.mas_lessThanOrEqualTo(0);
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.top.mas_equalTo(current.config.spacingBefore);
        return;
    }
    make.top.mas_equalTo(item.view.mas_bottom).offset(current.config.spacingBefore + item.config.spacingAfter);
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    if (item.view == nil) {
        make.bottom.mas_equalTo(-current.config.spacingAfter);
        return;
    }
    CGFloat offset = current.config.spacingAfter + item.config.spacingBefore;
    make.bottom.mas_equalTo(item.view.mas_top).mas_offset(-offset);
}

@end

@implementation TXTLayoutVerticalStrentchTransfer

+ (void)mas_makeBothSides:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current {
    
}

+ (void)mas_makeLeading:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    
}

+ (void)mas_makeTrailing:(MASConstraintMaker *)make current:(TXTStackLayoutItem *)current equalTo:(TXTStackLayoutItem *)item {
    
}

@end
