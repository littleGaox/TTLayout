//
//  TXTStackLayoutComponent.m
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import "TXTStackLayoutComponent.h"
#import "TXTLayoutTransfer.h"
#import "TXTContainerView.h"
#import "NSArray+Function.h"
#import <Masonry/Masonry.h>

static Class<TXTLayoutTransfer> TXTVerticalLayouterWithAlignment(TXTStackLayoutItemAlignment alignment) {
    switch (alignment) {
        case TXTStackLayoutItemAlignmentLeft:
            return [TXTLayoutVerticalLeftTransfer class];
        case TXTStackLayoutItemAlignmentRight:
            return [TXTLayoutVerticalRightTransfer class];
        case TXTStackLayoutItemAlignmentCenter:
            return [TXTLayoutVerticalCenterTransfer class];
        case TXTStackLayoutItemAlignmentStrentch:
            return [TXTLayoutVerticalStrentchTransfer class];
        case TXTStackLayoutItemAlignmentUnknow:
            break;
    }
    return nil;
}

static Class<TXTLayoutTransfer> TXTHorizontallLayouterWithAlignment(TXTStackLayoutItemAlignment alignment) {
    switch (alignment) {
        case TXTStackLayoutItemAlignmentLeft:
            return [TXTLayoutHorizontalLeftTransfer class];
        case TXTStackLayoutItemAlignmentRight:
            return [TXTLayoutHorizontalRightTransfer class];
        case TXTStackLayoutItemAlignmentCenter:
            return [TXTLayoutHorizontalCenterTransfer class];
        case TXTStackLayoutItemAlignmentStrentch:
            return [TXTLayoutHorizontalStrentchTransfer class];
        case TXTStackLayoutItemAlignmentUnknow:
            break;
    }
    return nil;
}

static Class<TXTLayoutTransfer> TXTStackLayouterWithStyle(TXTStackLayoutStyle style, TXTStackLayoutItemAlignment alignment) {
    switch (style) {
        case TXTStackLayoutStyleVertical:
            return TXTVerticalLayouterWithAlignment(alignment);
        case TXTStackLayoutStyleHorizontal:
            return TXTHorizontallLayouterWithAlignment(alignment);
    }
}

@interface TXTStackLayoutComponent ()

@property (nonatomic, strong) UIView *content;
@property (nonatomic, assign) TXTStackLayoutAttribute attribute;

@end

@implementation TXTStackLayoutComponent

+ (instancetype)stackLayoutWithAttribute:(TXTStackLayoutAttribute)attribute
                                   items:(NSArray<TXTStackLayoutItem *> *)items {
    TXTStackLayoutViewAttribute viewAttribute = {};
    return [self stackLayoutWithAttribute:attribute items:items viewAttribute:viewAttribute];
}

+ (instancetype)stackLayoutWithAttribute:(TXTStackLayoutAttribute)attribute
                                   items:(NSArray<TXTStackLayoutItem *> *)items
                           viewAttribute:(TXTStackLayoutViewAttribute)viewAttribute {
    if (attribute.alignmentItem == TXTStackLayoutItemAlignmentUnknow) {
        attribute.alignmentItem = TXTStackLayoutItemAlignmentLeft;
    }
    NSArray<TXTStackLayoutItem *> *lastItems = [items filter:^BOOL(TXTStackLayoutItem *item) {
        return item.view != nil;
    }];
    return [[self alloc] initWithAttribute:attribute
                                     items:lastItems
                             viewAttribute:viewAttribute];
}

- (instancetype)initWithAttribute:(TXTStackLayoutAttribute)attribute
                            items:(NSArray<TXTStackLayoutItem *> *)items
                viewAttribute:(TXTStackLayoutViewAttribute)viewAttribute {
    self = [super init];
    if (self) {
        self.attribute = attribute;
        
        [self initializeContent:viewAttribute];
        [self setupItems:items];
        [self setupConstraint:items];
    }
    return self;
}

- (void)initializeContent:(TXTStackLayoutViewAttribute)viewAttribute {
    if (self.content) {
        [self.content removeFromSuperview];
        self.content = nil;
    }
    self.content = [[TXTContainerView alloc] initWithFrame:CGRectZero];
    self.content.backgroundColor = viewAttribute.backgroundColor ?: UIColor.clearColor;
    self.content.layer.cornerRadius = viewAttribute.cornerRadious;
}

- (void)setupItems:(NSArray<TXTStackLayoutItem *> *)items {
    [items enumerateObjectsUsingBlock:^(TXTStackLayoutItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [self.content addSubview:obj.view];
    }];
}

- (void)setupConstraint:(NSArray<TXTStackLayoutItem *> *)items {
    NSUInteger count = items.count;
    __block TXTStackLayoutItem *preItem;
    [items enumerateObjectsUsingBlock:^(TXTStackLayoutItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        Class<TXTLayoutTransfer> class = [self layoutTransferWithItem:obj];
        [obj.view mas_makeConstraints:^(MASConstraintMaker *make) {
            [class mas_makeBothSides:make current:obj];
            [class mas_makeLeading:make current:obj equalTo:preItem];
            if (idx == count - 1) {
                [class mas_makeTrailing:make current:obj equalTo:nil];
            }
        }];
        preItem = obj;
    }];
}

- (Class<TXTLayoutTransfer>)layoutTransferWithItem:(TXTStackLayoutItem *)item {
    TXTStackLayoutItemAlignment align = (item.config.align == TXTStackLayoutItemAlignmentUnknow ? self.attribute.alignmentItem : item.config.align);
    return TXTStackLayouterWithStyle(self.attribute.style, align);
}

- (void)setupToView:(UIView *)view {
    [view addSubview:self.content];
    [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
        (self.attribute.alignmentSelf == TXTStackLayoutAlignmentCenter) ? make.center.mas_equalTo(0) : nil;
        (self.attribute.alignmentSelf & (1 << 0)) ? make.left.mas_equalTo(0) : nil;
        (self.attribute.alignmentSelf & (1 << 1)) ? make.top.mas_equalTo(0) : nil;
        (self.attribute.alignmentSelf & (1 << 2)) ? make.right.mas_equalTo(0) : nil;
        (self.attribute.alignmentSelf & (1 << 3)) ? make.bottom.mas_equalTo(0) : nil;
    }];
}

@end


@implementation TXTStackLayoutItem

+ (instancetype)itemWithView:(UIView *)view config:(TXTStackLayoutItemConfig)config {
    TXTStackLayoutItem *item = [TXTStackLayoutItem new];
    item->_view = view;
    item->_config = config;
    return item;
}

+ (instancetype)itemWithComponent:(TXTStackLayoutComponent *)component
                           config:(TXTStackLayoutItemConfig)config {
    TXTStackLayoutItem *item = [TXTStackLayoutItem new];
    item->_view = component.content;
    item->_config = config;
    return item;
}

@end
