//
//  NSArray+Function.h
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSArray (Function)

- (NSArray *)filter:(BOOL(^)(id))condition;

@end

NS_ASSUME_NONNULL_END
