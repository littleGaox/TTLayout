//
//  TXTLayoutTransfer.h
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Masonry/Masonry.h>
#import "TXTStackLayoutComponent.h"

NS_ASSUME_NONNULL_BEGIN

@protocol TXTLayoutTransfer <NSObject>

+ (void)mas_makeBothSides:(MASConstraintMaker *)make
                  current:(TXTStackLayoutItem *)current;
+ (void)mas_makeLeading:(MASConstraintMaker *)make
                current:(TXTStackLayoutItem *)current
                equalTo:(TXTStackLayoutItem *)item;
+ (void)mas_makeTrailing:(MASConstraintMaker *)make
                 current:(TXTStackLayoutItem *)current
                 equalTo:(TXTStackLayoutItem *)item;

@end


@interface TXTLayoutHorizontalLeftTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutHorizontalRightTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutHorizontalCenterTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutHorizontalStrentchTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutVerticalLeftTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutVerticalRightTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutVerticalCenterTransfer : NSObject <TXTLayoutTransfer>

@end

@interface TXTLayoutVerticalStrentchTransfer : NSObject <TXTLayoutTransfer>

@end


NS_ASSUME_NONNULL_END
