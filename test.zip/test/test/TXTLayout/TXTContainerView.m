//
//  TXTContainerView.m
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import "TXTContainerView.h"

@implementation TXTContainerView

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    __block BOOL isInside = NO;
    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (CGRectContainsPoint(obj.frame, point)) {
            isInside = YES;
            *stop = YES;
        }
    }];
    return isInside;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *view = [super hitTest:point withEvent:event];
    if (self == view) {
        return nil;
    }
    return view;
}

@end
