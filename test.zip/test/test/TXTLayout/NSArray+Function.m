//
//  NSArray+Function.m
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import "NSArray+Function.h"


@implementation NSArray (Function)

- (NSArray *)filter:(BOOL(^)(id))condition {
    NSMutableArray *mutableArray = @[].mutableCopy;
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (condition(obj)) {
            [mutableArray addObject:obj];
        }
    }];
    return [mutableArray copy];
}

@end
