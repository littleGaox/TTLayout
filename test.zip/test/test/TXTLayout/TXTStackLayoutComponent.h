//
//  TXTStackLayoutComponent.h
//  test
//
//  Created by gaoxinchuan on 2019/10/23.
//  Copyright © 2019 gaoxinchuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/*
 StackLayout 布局方向
 */
typedef NS_ENUM(NSUInteger, TXTStackLayoutStyle) {
    TXTStackLayoutStyleHorizontal,
    TXTStackLayoutStyleVertical,
};

/*
StackLayoutItem 布局格式
*/
typedef NS_ENUM(NSUInteger, TXTStackLayoutItemAlignment) {
    TXTStackLayoutItemAlignmentUnknow,
    TXTStackLayoutItemAlignmentCenter,
    TXTStackLayoutItemAlignmentLeft,
    TXTStackLayoutItemAlignmentRight,
    TXTStackLayoutItemAlignmentStrentch,
};

/*
StackLayout 布局格式
*/
typedef NS_ENUM(NSUInteger, TXTStackLayoutAlignment) {
    TXTStackLayoutAlignmentCenter = 0,
    TXTStackLayoutAlignmentLeftTop = 1 << 0 | 1 << 1,
    TXTStackLayoutAlignmentLeftBottom = 1 << 0 | 1 << 3,
    TXTStackLayoutAlignmentRightTop = 1 << 2 | 1 << 1,
    TXTStackLayoutAlignmentRightBottom = 1 << 2 | 1 << 3,
    TXTStackLayoutAlignmentFill = 1 << 0 | 1 << 1 | 1 << 2 | 1 << 3,
};

typedef struct __TXTStackLayoutAttribute {
    TXTStackLayoutStyle style;
    TXTStackLayoutAlignment alignmentSelf;
    TXTStackLayoutItemAlignment alignmentItem;
} TXTStackLayoutAttribute;

typedef struct __TXTStackLayoutItemConfig {
    TXTStackLayoutItemAlignment align;
    CGFloat spacingBefore;
    CGFloat spacingAfter;
} TXTStackLayoutItemConfig;

typedef struct __TXTStackLayoutViewAttribute {
    UIColor *backgroundColor;
    CGFloat cornerRadious;
} TXTStackLayoutViewAttribute;


@class TXTStackLayoutItem;

/*
 TXTStackLayoutComponent:
 垂直或水平的布局管理
 */
@interface TXTStackLayoutComponent : NSObject

/*
 attribute: 布局管理的属性
 items: 元素集合
 */
+ (instancetype)stackLayoutWithAttribute:(TXTStackLayoutAttribute)attribute
                                   items:(NSArray<TXTStackLayoutItem *> *)items;

+ (instancetype)stackLayoutWithAttribute:(TXTStackLayoutAttribute)attribute
                                   items:(NSArray<TXTStackLayoutItem *> *)items
                           viewAttribute:(TXTStackLayoutViewAttribute)viewAttribute;

- (void)setupToView:(UIView *)view;

@end

@interface TXTStackLayoutItem : NSObject

@property (nonatomic, strong, readonly) UIView *view;
@property (nonatomic, assign, readonly) TXTStackLayoutItemConfig config;

+ (instancetype)itemWithView:(UIView *)view config:(TXTStackLayoutItemConfig)config;
+ (instancetype)itemWithComponent:(TXTStackLayoutComponent *)component
                           config:(TXTStackLayoutItemConfig)config;

@end

NS_ASSUME_NONNULL_END
